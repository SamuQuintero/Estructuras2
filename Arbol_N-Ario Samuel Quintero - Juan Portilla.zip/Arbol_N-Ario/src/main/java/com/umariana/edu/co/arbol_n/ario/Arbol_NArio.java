/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.umariana.edu.co.arbol_n.ario;

import java.util.Scanner;

/**
 *
 * @author Samuel Quintero - Juan Portilla
 */
public class Arbol_NArio {

  public static void main(String[] args) {
        ArbolNary arbol = new ArbolNary();  
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            
            System.out.println("Menu:");
            System.out.println("1. Asignar raiz");
            System.out.println("2. Agregar hijo a un nodo");
            System.out.println("3. Mostrar recorrido en preorden");
            System.out.println("4. Salir");
            System.out.print("Selecciona una opcion: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1 -> {
                    System.out.print("Introduce el valor de la raíz: ");
                    float valorRaiz = scanner.nextFloat();
                    arbol.asignarRaiz( valorRaiz);
                    System.out.println("Raíz asignada.");
                }
                case 2 -> {
                    if (arbol.raiz == null) {
                        System.out.println("Primero asigna una raíz. ");
                    } else {
                        System.out.print("Introduce el  nodo padre: ");
                        float valorPadre = scanner.nextFloat();
                        System.out.print("Introduce el valor del nuevo hijo: ");
                        float valorHijo = scanner.nextFloat();
                        arbol.agregarHijo( valorPadre, valorHijo);
                    }
                }
                case 3 -> {
                    if (arbol.raiz == null) {
                        System.out.println("El árbol está vacío. ");
                    } else {
                        System.out.println("Recorrido en preorden: ");
                        arbol.recorridoPreorden();
                    }
                }
                case 4 -> System.out.println("Vuelve pronto!. ");
                default -> System.out.println("Opción no válida.");
            }
        } while (opcion != 4);

        scanner.close();
    }
}
