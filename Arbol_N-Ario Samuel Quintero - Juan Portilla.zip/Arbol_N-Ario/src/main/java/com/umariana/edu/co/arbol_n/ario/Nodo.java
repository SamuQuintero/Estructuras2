/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.umariana.edu.co.arbol_n.ario;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Samuel Quintero - Juan Portilla
 */
public class Nodo {

    float valor;  
    List<Nodo> hijos;  

    
    public Nodo(float valor) {
        this.valor = valor;
        hijos = new ArrayList<>();  
    }

    
    public void agregarHijo(Nodo hijo) {
        hijos.add(hijo);  
    }

}