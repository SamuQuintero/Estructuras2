/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.umariana.edu.co.arbol_n.ario;

/**
 *
 * @author Samuel Quintero - Juan Portilla
 */
public class ArbolNary {
    
    Nodo raiz;  

    
    public ArbolNary() {
        raiz = null;
    }

   
    public void asignarRaiz(float valor) {
        raiz = new Nodo(valor);  
    }
    
     
    public Nodo buscarNodo(Nodo nodo, float valor) {
        if (nodo == null) {
            return null;
        }
        if (nodo.valor == valor) {
            return nodo;
        }
        for (Nodo hijo : nodo.hijos) {
            Nodo encontrado = buscarNodo(hijo, valor);
            if (encontrado != null) {
                return encontrado;
            }
        }
        return null;
    }
    
        public void agregarHijo(float padreValor, float hijoValor) {
        Nodo padre = buscarNodo(raiz, padreValor);
        if (padre != null) {
            padre.agregarHijo(new Nodo(hijoValor));
        } else {
            System.out.println("Nodo padre no encontrado.");
        }
    }

    
    public void recorridoPreorden() {
        recorridoPreordenRecursivo(raiz);  
    }


    private void recorridoPreordenRecursivo(Nodo nodo) {
        if (nodo == null) {
            return;
        }

        
        System.out.print(nodo.valor + " ");

        
        for (Nodo hijo : nodo.hijos) {
            recorridoPreordenRecursivo(hijo);  
        }
    }
}